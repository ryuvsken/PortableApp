-MAc OS X Leopard-
   -v0.1-

------------
By AnthoNYC
------------

Don't worry, it's easy! :D
============
Install:

1. Extract the file
2. Go to your Programs Files
3. Open up the RocketDock file
4. Place the Leopard file in the Skins folder

(You can here and enjoy your skin, or follow further down if the indicator won't work)
5. After you put it in the Skins folder, open up the Leopard File
6. Copy the indicator.png file
7. Go back to the main directory of RocketDock (C:Program Files/RocketDock)
8. Go to Defaults folder
9. Paste the indicator file in defaults
10. Make a copy of your DefaultIndicator file
11. Once you did that, go inside DefaultIndicator file, delete the indicator.png
    and drag in the new indicator.png file from Leopard. 
12. Now your all done, make sure you the "Running Applications Indicators"
    in Dock Settings is checked, and change the style to Leopard.
============

More colors coming soon!
E-mail me if you want me to do a specific color :D


Questions/Suggestions/Complaints?
email me at: tonyxunit@yahoo.com

Check out my DeviantArt page also!
http://anthony-c.deviantart.com/
----------

ENJOY! :D 

  |  |
  |  |

 \____/
