;!define DEBUG_SEGMENT_[segment name]

;!define DEBUG_SEGMENT_Svc

;!define DEBUG_SEGMENT_Custom
