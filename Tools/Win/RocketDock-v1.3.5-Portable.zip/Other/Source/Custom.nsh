/*
${SegmentFile}

Var [variables]

${Segment[hook]}
    ...
!macroend

${Segment[hook]}
    ...
!macroend

...
*/