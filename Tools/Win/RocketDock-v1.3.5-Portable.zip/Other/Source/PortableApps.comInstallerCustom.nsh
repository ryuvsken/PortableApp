﻿/*
From PortableApps.com Format™ 3.4 (2016-08-19)
Custom Code may be included with your installer by including a file called PortableApps.comInstallerCustom.nsh within the Other\Source directory. This file is coded in NSIS and can include 3 macros: CustomCodePreInstall (which is run before installation), CustomCodePostInstall (which is run after installation) and CustomCodeOptionalCleanup (which is run at the beginning of installation if the optional section of an installer is not selected, intended for use in app upgrades when the existing app may have had the optional section included). In addition to the standard NSIS functions, the following NSIS features are available: ConfigRead, ConfigReadS, ConfigWrite, ConfigWriteS, GetParent, GetRoot, VersionCompare and the LogicLib features of NSIS. Please ensure that the file is Unicode encoded (not ANSI/DOS).
*/
/*
!macro CustomCodePostInstall
	;put the user.ini file in instdir to disable splash screen
	SetOutPath $INSTDIR
	IfFileExists "$INSTDIR\$BaseName.ini" 0 +2
		WriteINIStr "$INSTDIR\$BaseName.ini" $BaseName DisableSplashScreen true
		File /x thumbs.db "..\..\$BaseName.ini"
!macroend


!macro CustomCodePostInstall
	CreateDirectory $INSTDIR\profile

	SetOutPath $INSTDIR
	File /x thumbs.db "..\..\launcher.visualelementsmanifest.xml"
	File /x thumbs.db "..\..\Resources.pri"
	File /x thumbs.db "..\..\installation_status.xml"
	File /x thumbs.db "..\..\installer_prefs.json"
;	File /x thumbs.db "..\..\Opera Developer.bat"

	SetOutPath $INSTDIR\Assets
	File /r /x thumbs.db "..\..\Assets\*.*"

	SetOutPath $INSTDIR\26.0.1656.24
	File /r /x thumbs.db "..\..\26.0.1656.24\*.*"

;	File /r /x thumbs.db "..\..\*.*"
;	RMDir /r $INSTDIR\Data
;	CreateDirectory $INSTDIR\Data\cache
;	CreateDirectory $INSTDIR\profile
!macroend

*/