${SegmentFile}

${SegmentPostPrimary}
	
	;if this key exist, overwrite its value: HKCU\Software\Microsoft\Windows\CurrentVersion\Run "RocketDock"=""
	ClearErrors
	ReadRegStr $0 HKCU SOFTWARE\Microsoft\Windows\CurrentVersion\Run "RocketDock"
	${IfNot} ${Errors}
		${DebugMsg} "Overwrite, RocketDock start-up run."
		WriteRegStr HKCU SOFTWARE\Microsoft\Windows\CurrentVersion\Run "RocketDock" '"$EXEDIR\${AppID}.exe"'
	${EndIf}
!macroend
