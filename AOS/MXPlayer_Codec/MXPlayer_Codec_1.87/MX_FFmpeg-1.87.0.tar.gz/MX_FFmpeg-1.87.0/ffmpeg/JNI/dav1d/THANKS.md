# The dav1d project and VideoLAN association would like to thank

## AOM
The Alliance for Open Media (AOM) for funding this project.

## Companies
* Two Orioles LLC, for important coding effort
* VideoLabs SAS

## Projects
* VideoLAN
* FFmpeg
* libplacebo

## Individual

And all the dav1d Authors (git shortlog -sn), including:

Janne Grunau, Ronald S. Bultje, Martin Storsjö, Henrik Gramner, James Almer,
Marvin Scholz, Luc Trudeau, Jean-Baptiste Kempf, Victorien Le Couviour--Tuffet,
David Michael Barr, Hugo Beauzée-Luyssen, Steve Lhomme, Nathan E. Egge,
Francois Cartegnie, Konstantin Pavlov, Liwei Wang, Xuefeng Jiang,
Derek Buitenhuis, Raphaël Zumer, Niklas Haas, Michael Bradshaw, Kyle Siefring,
Raphael Zumer, Boyuan Xiao, Thierry Foucu, Matthias Dressel, Thomas Daede,
Rupert Swarbrick, Jan Beich, Dale Curtis, SmilingWolf, Tristan Laurent,
Vittorio Giovara, Rostislav Pehlivanov, Shiz, skal, Steinar Midtskogen,
Luca Barbato, Justin Bull, Jean-Yves Avenard, Timo Gurr, Fred Barbier,
Anisse Astier, Pablo Stebler, Nicolas Frattaroli, Mark Shuttleworth.
